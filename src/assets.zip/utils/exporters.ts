import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { ResumeData } from '../types/resume';

// 1. Export PDF using Canvas Capture
export async function exportToPDF(elementId: string, filename: string, pageSize: 'A4' | 'Letter' = 'A4'): Promise<boolean> {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error('Element not found: ' + elementId);
    return false;
  }

  try {
    // Create an isolated wrapper to avoid oklch/CSS variable color issues in html2canvas
    const wrapper = document.createElement('div');
    wrapper.style.cssText = `
      position: fixed;
      top: -9999px;
      left: -9999px;
      width: ${element.scrollWidth}px;
      background: #ffffff;
      font-family: Arial, sans-serif;
      color: #111827;
      z-index: -1;
    `;

    // Clone the element deeply
    const clone = element.cloneNode(true) as HTMLElement;
    clone.style.background = '#ffffff';
    clone.style.color = '#111827';

    // Replace any oklch/CSS vars in inline styles and walk all descendants
    const sanitizeColors = (el: HTMLElement) => {
      const computedStyle = window.getComputedStyle(el);
      // Force solid background and text colors to avoid oklch issues
      const bg = computedStyle.backgroundColor;
      const color = computedStyle.color;
      // If color contains oklch, fall back to black/white
      if (bg && bg.includes('oklch')) {
        el.style.backgroundColor = '#ffffff';
      }
      if (color && color.includes('oklch')) {
        el.style.color = '#111827';
      }
      Array.from(el.children).forEach(child => sanitizeColors(child as HTMLElement));
    };

    sanitizeColors(clone);
    wrapper.appendChild(clone);
    document.body.appendChild(wrapper);

    const opt = {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff',
      // Override color parser to ignore unsupported color functions
      onclone: (clonedDoc: Document) => {
        // Remove all <style> tags with oklch to avoid parsing failures
        const styles = clonedDoc.querySelectorAll('style');
        styles.forEach((style) => {
          if (style.textContent && style.textContent.includes('oklch')) {
            style.remove();
          }
        });
      }
    };

    const canvas = await html2canvas(clone, opt);

    // Clean up temporary element
    document.body.removeChild(wrapper);

    const imgData = canvas.toDataURL('image/jpeg', 0.98);
    
    const format = pageSize === 'Letter' ? 'letter' : 'a4';
    const pdf = new jsPDF('p', 'mm', format);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    
    // Calculate exact scaled height
    const imgWidth = pdfWidth;
    const imgHeight = (canvasHeight * pdfWidth) / canvasWidth;
    
    let heightLeft = imgHeight;
    let position = 0;
    
    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
    heightLeft -= pdfHeight;
    
    // Dynamic page break support for multi-page resumes
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
    }
    
    pdf.save(`${filename.replace(/\s+/g, '_')}.pdf`);
    return true;
  } catch (error) {
    console.error('PDF export failed:', error);
    // Fallback: try with the original element directly
    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
        ignoreElements: (el) => {
          // Skip elements that might have oklch colors in their stylesheet
          return el.tagName === 'STYLE' && el.textContent?.includes('oklch') === true;
        }
      });
      const imgData = canvas.toDataURL('image/jpeg', 0.98);
      const format = pageSize === 'Letter' ? 'letter' : 'a4';
      const pdf = new jsPDF('p', 'mm', format);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pdfWidth;
      const imgHeight = (canvas.height * pdfWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pdfHeight;
      }
      pdf.save(`${filename.replace(/\s+/g, '_')}.pdf`);
      return true;
    } catch (fallbackError) {
      console.error('PDF export fallback also failed:', fallbackError);
      return false;
    }
  }
}

// 2. Export DOCX via Native Word HTML structure
export function exportToDOCX(data: ResumeData) {
  const name = data.personalInfo.fullName || 'Candidate';
  const title = data.personalInfo.professionalTitle || 'Professional';
  
  const htmlContent = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <title>${name} - Resume</title>
      <!--[if gte mso 9]>
      <xml>
        <w:WordDocument>
          <w:View>Print</w:View>
          <w:Zoom>100</w:Zoom>
          <w:DoNotOptimizeForBrowser/>
        </w:WordDocument>
      </xml>
      <![endif]-->
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.25; font-size: 10.5pt; color: #222222; margin: 1in; }
        h1 { font-size: 18pt; font-weight: bold; color: #1e3a8a; margin-bottom: 2pt; text-align: center; text-transform: uppercase; }
        .title { text-align: center; font-size: 12pt; font-style: italic; color: #4b5563; margin-bottom: 8pt; }
        .contact { text-align: center; font-size: 9.5pt; color: #4b5563; margin-bottom: 15pt; border-bottom: 2px solid #e5e7eb; padding-bottom: 8pt; }
        h2 { font-size: 12.5pt; color: #1e3a8a; border-bottom: 1.5px solid #1e3a8a; padding-bottom: 2pt; margin-top: 15pt; margin-bottom: 6pt; text-transform: uppercase; }
        .section-desc { text-align: justify; margin-bottom: 10pt; }
        .entry-header { font-weight: bold; font-size: 11pt; display: block; margin-top: 8pt; }
        .entry-details { font-style: italic; color: #4b5563; font-size: 9.5pt; }
        .entry-date { float: right; font-weight: normal; color: #4b5563; }
        .bullets { margin-top: 4pt; margin-bottom: 4pt; padding-left: 18px; }
        .bullet-item { margin-bottom: 3pt; text-align: justify; }
        .skills-section { margin-bottom: 10pt; }
        .skill-item { margin-bottom: 4pt; }
      </style>
    </head>
    <body>
      <h1>${name}</h1>
      <div class="title">${title}</div>
      <div class="contact">
        ${data.personalInfo.email} | ${data.personalInfo.phone} | ${data.personalInfo.address}
        ${data.personalInfo.linkedin ? ` | ${data.personalInfo.linkedin}` : ''}
        ${data.personalInfo.github ? ` | ${data.personalInfo.github}` : ''}
        ${data.personalInfo.portfolio ? ` | ${data.personalInfo.portfolio}` : ''}
      </div>

      ${data.summary ? `
        <h2>Professional Summary</h2>
        <div class="section-desc">${data.summary}</div>
      ` : ''}

      ${data.experience.length > 0 ? `
        <h2>Work Experience</h2>
        ${data.experience.map(exp => `
          <div>
            <div class="entry-header">
              <span>${exp.role}</span> at <span>${exp.company}</span>
              <span style="float: right; font-weight: normal;">${exp.startDate} - ${exp.current ? 'Present' : exp.endDate}</span>
            </div>
            ${exp.location ? `<div class="entry-details">${exp.location}</div>` : ''}
            <ul class="bullets">
              ${exp.responsibilities.split('\n').map(bullet => bullet.trim() ? `<li class="bullet-item">${bullet.replace(/^•\s*/, '')}</li>` : '').join('')}
              ${exp.achievements ? `<li class="bullet-item"><strong>Key Achievement:</strong> ${exp.achievements}</li>` : ''}
            </ul>
          </div>
        `).join('')}
      ` : ''}

      ${data.education.length > 0 ? `
        <h2>Education</h2>
        ${data.education.map(edu => `
          <div>
            <div class="entry-header">
              <span>${edu.degree}</span>
              <span style="float: right; font-weight: normal;">${edu.startYear} - ${edu.endYear}</span>
            </div>
            <div class="entry-details">${edu.school} ${edu.city ? `| ${edu.city}` : ''} ${edu.cgpaOrPercentage ? `| Grade: ${edu.cgpaOrPercentage}` : ''}</div>
            ${edu.description ? `<p style="margin-top: 3pt; font-size: 9.5pt; font-style: italic;">${edu.description}</p>` : ''}
          </div>
        `).join('')}
      ` : ''}

      ${data.skills.length > 0 ? `
        <h2>Skills</h2>
        <div class="skills-section">
          ${data.skills.filter(s => s.type === 'technical').length > 0 ? `
            <div class="skill-item"><strong>Technical Skills:</strong> ${data.skills.filter(s => s.type === 'technical').map(s => s.name).join(', ')}</div>
          ` : ''}
          ${data.skills.filter(s => s.type === 'soft').length > 0 ? `
            <div class="skill-item"><strong>Soft Skills:</strong> ${data.skills.filter(s => s.type === 'soft').map(s => s.name).join(', ')}</div>
          ` : ''}
        </div>
      ` : ''}

      ${data.projects.length > 0 ? `
        <h2>Projects</h2>
        ${data.projects.map(proj => `
          <div>
            <div class="entry-header">
              <span>${proj.name}</span>
              ${proj.githubLink ? `<span style="font-weight: normal; font-size: 9pt; float: right;"><a href="${proj.githubLink}">GitHub</a></span>` : ''}
            </div>
            <p style="margin-top: 2pt; margin-bottom: 2pt;">${proj.description}</p>
            <div style="font-size: 9.5pt; color: #4b5563; margin-bottom: 4pt;"><strong>Technologies:</strong> ${proj.technologies.join(', ')}</div>
            ${proj.achievements ? `<p style="font-size: 9.5pt; margin-top: 2pt;"><strong>Key Achievement:</strong> ${proj.achievements}</p>` : ''}
          </div>
        `).join('')}
      ` : ''}

      ${data.certifications.length > 0 ? `
        <h2>Certifications</h2>
        ${data.certifications.map(cert => `
          <div style="margin-bottom: 6pt;">
            <strong>${cert.name}</strong> - ${cert.issuer} (${cert.date})
            ${cert.credentialId ? `<div style="font-size: 9pt; color: #4b5563;">Credential ID: ${cert.credentialId}</div>` : ''}
          </div>
        `).join('')}
      ` : ''}

      ${data.languages.length > 0 ? `
        <h2>Languages</h2>
        <p>${data.languages.map(l => `${l.name} (${l.speaking} Speaking, ${l.writing} Writing)`).join(' | ')}</p>
      ` : ''}
    </body>
    </html>
  `;

  // Create Word readable doc bundle
  const blob = new Blob(['\ufeff' + htmlContent], { type: 'application/msword' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${name.replace(/\s+/g, '_')}_Resume.doc`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// 3. Export to Plain Text TXT
export function exportToTXT(data: ResumeData) {
  const divider = '\n' + '='.repeat(60) + '\n';
  const subDivider = '-'.repeat(40);
  
  let txt = '';
  txt += `${data.personalInfo.fullName.toUpperCase()}\n`;
  txt += `${data.personalInfo.professionalTitle}\n`;
  txt += `${data.personalInfo.email} | ${data.personalInfo.phone} | ${data.personalInfo.address}\n`;
  if (data.personalInfo.linkedin) txt += `LinkedIn: ${data.personalInfo.linkedin}\n`;
  if (data.personalInfo.github) txt += `GitHub: ${data.personalInfo.github}\n`;
  if (data.personalInfo.portfolio) txt += `Portfolio: ${data.personalInfo.portfolio}\n`;
  
  txt += divider;
  txt += 'PROFESSIONAL SUMMARY\n';
  txt += subDivider + '\n';
  txt += `${data.summary || 'N/A'}\n`;
  
  txt += divider;
  txt += 'EXPERIENCE\n';
  txt += subDivider + '\n';
  if (data.experience.length > 0) {
    data.experience.forEach(exp => {
      txt += `${exp.role.toUpperCase()} - ${exp.company}\n`;
      txt += `${exp.startDate} to ${exp.current ? 'Present' : exp.endDate} | ${exp.location || ''}\n`;
      txt += `Responsibilities:\n${exp.responsibilities}\n`;
      if (exp.achievements) txt += `Key Achievement: ${exp.achievements}\n`;
      txt += '\n';
    });
  } else {
    txt += 'N/A\n';
  }
  
  txt += divider;
  txt += 'EDUCATION\n';
  txt += subDivider + '\n';
  if (data.education.length > 0) {
    data.education.forEach(edu => {
      txt += `${edu.degree} | ${edu.school} (${edu.startYear} - ${edu.endYear})\n`;
      if (edu.cgpaOrPercentage) txt += `Grade: ${edu.cgpaOrPercentage}\n`;
      if (edu.description) txt += `${edu.description}\n`;
      txt += '\n';
    });
  } else {
    txt += 'N/A\n';
  }
  
  txt += divider;
  txt += 'SKILLS\n';
  txt += subDivider + '\n';
  const techSkills = data.skills.filter(s => s.type === 'technical').map(s => s.name);
  const softSkills = data.skills.filter(s => s.type === 'soft').map(s => s.name);
  txt += `Technical: ${techSkills.join(', ') || 'N/A'}\n`;
  txt += `Soft Skills: ${softSkills.join(', ') || 'N/A'}\n`;
  
  txt += divider;
  txt += 'PROJECTS\n';
  txt += subDivider + '\n';
  if (data.projects.length > 0) {
    data.projects.forEach(p => {
      txt += `${p.name.toUpperCase()}\n`;
      if (p.githubLink) txt += `Code: ${p.githubLink}\n`;
      if (p.liveLink) txt += `Demo: ${p.liveLink}\n`;
      txt += `Description: ${p.description}\n`;
      txt += `Technologies: ${p.technologies.join(', ')}\n`;
      if (p.achievements) txt += `Key Outcome: ${p.achievements}\n`;
      txt += '\n';
    });
  } else {
    txt += 'N/A\n';
  }

  txt += divider;
  txt += 'CERTIFICATIONS\n';
  txt += subDivider + '\n';
  if (data.certifications.length > 0) {
    data.certifications.forEach(c => {
      txt += `${c.name} - ${c.issuer} (${c.date})\n`;
      if (c.credentialId) txt += `ID: ${c.credentialId}\n`;
      txt += '\n';
    });
  } else {
    txt += 'N/A\n';
  }

  const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${data.personalInfo.fullName.replace(/\s+/g, '_')}_Resume.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// 4. Export to JSON Schema
export function exportToJSON(data: ResumeData, theme: any, templateId: string) {
  const bundle = {
    id: data.id,
    title: data.title,
    lastSaved: new Date().toISOString(),
    personalInfo: data.personalInfo,
    summary: data.summary,
    education: data.education,
    skills: data.skills,
    experience: data.experience,
    projects: data.projects,
    certifications: data.certifications,
    internships: data.internships,
    achievements: data.achievements,
    languages: data.languages,
    interests: data.interests,
    references: data.references,
    themeSettings: theme,
    templateId
  };

  const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${data.title.replace(/\s+/g, '_')}_backup.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// 5. Trigger Native Vector Print Dialogue
export function printResume() {
  window.print();
}
