import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ResumeData, ThemeSettings, SavedResume, PersonalInfo, Education, Skill, Experience, Project, Certification, Internship, Language, Reference } from '../types/resume';

interface ResumeState {
  // Active Resume State
  resumeData: ResumeData;
  themeSettings: ThemeSettings;
  templateId: string;
  
  // Dashboard & Navigation State
  savedResumes: SavedResume[];
  activeStep: number;
  isDarkMode: boolean;
  apiKey: string;
  apiProvider: 'openai' | 'gemini';
  
  // Actions
  updatePersonalInfo: (info: Partial<PersonalInfo>) => void;
  updateSummary: (summary: string) => void;
  
  addEducation: (edu: Omit<Education, 'id'>) => void;
  updateEducation: (id: string, edu: Partial<Education>) => void;
  removeEducation: (id: string) => void;
  reorderEducation: (list: Education[]) => void;
  
  addSkill: (skill: Omit<Skill, 'id'>) => void;
  updateSkill: (id: string, skill: Partial<Skill>) => void;
  removeSkill: (id: string) => void;
  reorderSkills: (list: Skill[]) => void;
  
  addExperience: (exp: Omit<Experience, 'id'>) => void;
  updateExperience: (id: string, exp: Partial<Experience>) => void;
  removeExperience: (id: string) => void;
  reorderExperience: (list: Experience[]) => void;
  
  addProject: (proj: Omit<Project, 'id'>) => void;
  updateProject: (id: string, proj: Partial<Project>) => void;
  removeProject: (id: string) => void;
  reorderProjects: (list: Project[]) => void;
  
  addCertification: (cert: Omit<Certification, 'id'>) => void;
  updateCertification: (id: string, cert: Partial<Certification>) => void;
  removeCertification: (id: string) => void;
  
  addInternship: (intern: Omit<Internship, 'id'>) => void;
  updateInternship: (id: string, intern: Partial<Internship>) => void;
  removeInternship: (id: string) => void;
  
  addAchievement: (achievement: string) => void;
  updateAchievement: (index: number, achievement: string) => void;
  removeAchievement: (index: number) => void;
  
  addLanguage: (lang: Omit<Language, 'id'>) => void;
  updateLanguage: (id: string, lang: Partial<Language>) => void;
  removeLanguage: (id: string) => void;
  
  addInterest: (interest: string) => void;
  removeInterest: (index: number) => void;
  
  addReference: (ref: Omit<Reference, 'id'>) => void;
  updateReference: (id: string, ref: Partial<Reference>) => void;
  removeReference: (id: string) => void;
  
  updateThemeSettings: (settings: Partial<ThemeSettings>) => void;
  setTemplateId: (id: string) => void;
  setActiveStep: (step: number) => void;
  toggleDarkMode: () => void;
  setApiKey: (key: string, provider: 'openai' | 'gemini') => void;
  
  // Saved Resumes Management
  saveCurrentResume: () => void;
  loadResume: (id: string) => void;
  deleteResume: (id: string) => void;
  createNewResume: () => void;
  importResumeJSON: (jsonString: string) => boolean;
}

const defaultPersonalInfo: PersonalInfo = {
  fullName: 'Alex Morgan',
  professionalTitle: 'Senior Full Stack Engineer',
  email: 'alex.morgan@tech.dev',
  phone: '+1 (555) 234-5678',
  address: 'San Francisco, CA',
  linkedin: 'linkedin.com/in/alexmorgan',
  github: 'github.com/alexmorgan',
  portfolio: 'alexmorgan.dev',
  photo: ''
};

const defaultSummary = 'Innovative and detail-oriented Senior Software Engineer with 5+ years of experience designing, building, and deploying highly scalable web applications. Proficient in React, Node.js, TypeScript, and AWS cloud infrastructure. Demonstrated expertise in leading cross-functional teams and optimizing application performance, resulting in a 35% reduction in page load times. Committed to clean code, test-driven development, and creating seamless user experiences.';

const defaultEducation: Education[] = [
  {
    id: 'edu-1',
    degree: 'B.S. in Computer Science',
    school: 'Stanford University',
    city: 'Stanford, CA',
    cgpaOrPercentage: '3.82 GPA',
    startYear: '2016',
    endYear: '2020',
    description: 'Specialization in Software Theory. Coursework in Distributed Systems, Database Management, and UI Design.'
  }
];

const defaultSkills: Skill[] = [
  { id: 'sk-1', name: 'JavaScript / TypeScript', type: 'technical', rating: 5 },
  { id: 'sk-2', name: 'React.js / Next.js', type: 'technical', rating: 5 },
  { id: 'sk-3', name: 'Node.js / Express', type: 'technical', rating: 4 },
  { id: 'sk-4', name: 'PostgreSQL / MongoDB', type: 'technical', rating: 4 },
  { id: 'sk-5', name: 'AWS (S3, EC2, Lambda)', type: 'technical', rating: 4 },
  { id: 'sk-6', name: 'Git & CI/CD Pipelines', type: 'technical', rating: 5 },
  { id: 'sk-7', name: 'Tailwind CSS / CSS3', type: 'technical', rating: 5 },
  { id: 'sk-8', name: 'Technical Leadership', type: 'soft', rating: 4 },
  { id: 'sk-9', name: 'Effective Communication', type: 'soft', rating: 5 },
  { id: 'sk-10', name: 'Problem Solving', type: 'soft', rating: 5 },
  { id: 'sk-11', name: 'Agile/Scrum', type: 'soft', rating: 4 }
];

const defaultExperience: Experience[] = [
  {
    id: 'exp-1',
    company: 'Innovate Solutions Inc.',
    role: 'Senior Software Engineer',
    location: 'San Francisco, CA',
    startDate: '2022-06',
    endDate: '',
    current: true,
    responsibilities: 'Led a team of 4 frontend engineers to rebuild the core dashboard application using Next.js and Tailwind CSS, increasing performance scores by 40%.\nSpearheaded adoption of TypeScript across all services, lowering runtime errors by 22%.\nCollaborated with product teams to design scalable backend APIs using Node.js and PostgreSQL.',
    achievements: 'Received "Innovator of the Year" award in 2023 for designing a real-time analytics engine.'
  },
  {
    id: 'exp-2',
    company: 'ByteTech Global',
    role: 'Full Stack Engineer',
    location: 'Austin, TX',
    startDate: '2020-07',
    endDate: '2022-05',
    current: false,
    responsibilities: 'Maintained and developed core e-commerce features handling over $2M in monthly sales.\nImplemented payment gateway integrations using Stripe and optimized SQL database queries to reduce checkout delay by 1.5 seconds.\nBuilt automated Jest unit testing suites covering 85% of critical codebase routes.',
    achievements: 'Optimized PostgreSQL caching, reducing database cost by 15% annually.'
  }
];

const defaultProjects: Project[] = [
  {
    id: 'proj-1',
    name: 'SaaS Dashboard Starter',
    githubLink: 'github.com/alexmorgan/saas-dashboard',
    liveLink: 'saas-starter-demo.dev',
    description: 'A premium, production-ready SaaS landing page and dashboard template built with React, Tailwind CSS, and Framer Motion. Fully responsive with glassmorphic visuals and dark mode.',
    technologies: ['React', 'Tailwind CSS', 'Framer Motion', 'Zustand'],
    achievements: 'Gained 2,000+ GitHub Stars and 300 forks within the developer community.'
  },
  {
    id: 'proj-2',
    name: 'CollabDoc: Real-time Text Editor',
    githubLink: 'github.com/alexmorgan/collab-doc',
    liveLink: 'collab-doc-editor.online',
    description: 'Collaborative rich-text writing platform supporting multi-user editing, cursors sync, and PDF exports. Uses WebSockets and CRDTs for sync resolution.',
    technologies: ['React', 'Node.js', 'Socket.io', 'MongoDB'],
    achievements: 'Successfully handles up to 50 concurrent editors per document without lag.'
  }
];

const defaultCertifications: Certification[] = [
  {
    id: 'cert-1',
    name: 'AWS Certified Solutions Architect – Associate',
    issuer: 'Amazon Web Services (AWS)',
    date: '2023-09',
    credentialId: 'AWS-CSAA-90812',
    credentialUrl: 'aws.amazon.com/verification'
  }
];

const defaultInternships: Internship[] = [
  {
    id: 'int-1',
    company: 'FutureLabs Inc.',
    role: 'Frontend Engineering Intern',
    duration: '3 Months (Summer 2019)',
    description: 'Created dynamic UI mockups, worked closely with the UI/UX team, and implemented client-side data filters using React and Redux.'
  }
];

const defaultAchievements = [
  'Won 1st place in the Stanford annual hackathon (Category: Cloud Innovations, 2019)',
  'Maintained an active open-source contribution streak of 200+ days',
  'Mentored 15+ junior developers through online coding community bootcamps'
];

const defaultLanguages: Language[] = [
  { id: 'lang-1', name: 'English', speaking: 'Native', reading: 'Native', writing: 'Native' },
  { id: 'lang-2', name: 'Spanish', speaking: 'Conversational', reading: 'Fluent', writing: 'Conversational' }
];

const defaultInterests = ['Coding & Open Source', 'Landscape Photography', 'Hiking & Mountaineering', 'Independent Music Production'];

const defaultReferences: Reference[] = [
  {
    id: 'ref-1',
    name: 'Sarah Jenkins',
    company: 'Innovate Solutions Inc.',
    role: 'Director of Engineering',
    phone: '+1 (555) 987-6543',
    email: 'sarah.jenkins@innovatesolutions.com'
  }
];

const defaultThemeSettings: ThemeSettings = {
  accentColor: '#3b82f6', // Corporate blue
  fontFamily: 'Inter',
  fontSize: 'md',
  lineHeight: 'normal',
  margins: 'md',
  borderRadius: 'md',
  headingStyle: 'underline',
  showPhoto: true,
  showSocialIcons: true,
  pageSize: 'A4'
};

const createNewResumeData = (id: string, title = 'Untitled Resume'): ResumeData => ({
  id,
  title,
  lastSaved: new Date().toISOString(),
  personalInfo: {
    fullName: '',
    professionalTitle: '',
    email: '',
    phone: '',
    address: '',
    linkedin: '',
    github: '',
    portfolio: '',
    photo: ''
  },
  summary: '',
  education: [],
  skills: [],
  experience: [],
  projects: [],
  certifications: [],
  internships: [],
  achievements: [],
  languages: [],
  interests: [],
  references: []
});

export const useResumeStore = create<ResumeState>()(
  persist(
    (set, get) => ({
      // Active Resume Data
      resumeData: {
        id: 'default-resume-id',
        title: 'Full Stack Engineer Resume',
        lastSaved: new Date().toISOString(),
        personalInfo: defaultPersonalInfo,
        summary: defaultSummary,
        education: defaultEducation,
        skills: defaultSkills,
        experience: defaultExperience,
        projects: defaultProjects,
        certifications: defaultCertifications,
        internships: defaultInternships,
        achievements: defaultAchievements,
        languages: defaultLanguages,
        interests: defaultInterests,
        references: defaultReferences
      },
      themeSettings: defaultThemeSettings,
      templateId: 'modern-minimal',
      
      // Dashboard & Settings
      savedResumes: [],
      activeStep: 0,
      isDarkMode: false,
      apiKey: '',
      apiProvider: 'openai',
      
      // Personal Info
      updatePersonalInfo: (info) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          personalInfo: { ...state.resumeData.personalInfo, ...info },
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Summary
      updateSummary: (summary) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          summary,
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Education
      addEducation: (edu) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          education: [...state.resumeData.education, { ...edu, id: `edu-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateEducation: (id, edu) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          education: state.resumeData.education.map((item) => item.id === id ? { ...item, ...edu } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeEducation: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          education: state.resumeData.education.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      reorderEducation: (list) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          education: list,
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Skills
      addSkill: (skill) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          skills: [...state.resumeData.skills, { ...skill, id: `sk-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateSkill: (id, skill) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          skills: state.resumeData.skills.map((item) => item.id === id ? { ...item, ...skill } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeSkill: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          skills: state.resumeData.skills.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      reorderSkills: (list) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          skills: list,
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Experience
      addExperience: (exp) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          experience: [...state.resumeData.experience, { ...exp, id: `exp-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateExperience: (id, exp) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          experience: state.resumeData.experience.map((item) => item.id === id ? { ...item, ...exp } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeExperience: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          experience: state.resumeData.experience.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      reorderExperience: (list) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          experience: list,
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Projects
      addProject: (proj) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          projects: [...state.resumeData.projects, { ...proj, id: `proj-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateProject: (id, proj) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          projects: state.resumeData.projects.map((item) => item.id === id ? { ...item, ...proj } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeProject: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          projects: state.resumeData.projects.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      reorderProjects: (list) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          projects: list,
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Certifications
      addCertification: (cert) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          certifications: [...state.resumeData.certifications, { ...cert, id: `cert-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateCertification: (id, cert) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          certifications: state.resumeData.certifications.map((item) => item.id === id ? { ...item, ...cert } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeCertification: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          certifications: state.resumeData.certifications.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Internships
      addInternship: (intern) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          internships: [...state.resumeData.internships, { ...intern, id: `int-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateInternship: (id, intern) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          internships: state.resumeData.internships.map((item) => item.id === id ? { ...item, ...intern } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeInternship: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          internships: state.resumeData.internships.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Achievements
      addAchievement: (achievement) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          achievements: [...state.resumeData.achievements, achievement],
          lastSaved: new Date().toISOString()
        }
      })),
      updateAchievement: (index, achievement) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          achievements: state.resumeData.achievements.map((item, idx) => idx === index ? achievement : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeAchievement: (index) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          achievements: state.resumeData.achievements.filter((_, idx) => idx !== index),
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Languages
      addLanguage: (lang) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          languages: [...state.resumeData.languages, { ...lang, id: `lang-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateLanguage: (id, lang) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          languages: state.resumeData.languages.map((item) => item.id === id ? { ...item, ...lang } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeLanguage: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          languages: state.resumeData.languages.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Interests
      addInterest: (interest) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          interests: [...state.resumeData.interests, interest],
          lastSaved: new Date().toISOString()
        }
      })),
      removeInterest: (index) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          interests: state.resumeData.interests.filter((_, idx) => idx !== index),
          lastSaved: new Date().toISOString()
        }
      })),
      
      // References
      addReference: (ref) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          references: [...state.resumeData.references, { ...ref, id: `ref-${Date.now()}` }],
          lastSaved: new Date().toISOString()
        }
      })),
      updateReference: (id, ref) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          references: state.resumeData.references.map((item) => item.id === id ? { ...item, ...ref } : item),
          lastSaved: new Date().toISOString()
        }
      })),
      removeReference: (id) => set((state) => ({
        resumeData: {
          ...state.resumeData,
          references: state.resumeData.references.filter((item) => item.id !== id),
          lastSaved: new Date().toISOString()
        }
      })),
      
      // Themes, steps, keys, modes
      updateThemeSettings: (settings) => set((state) => ({
        themeSettings: { ...state.themeSettings, ...settings }
      })),
      setTemplateId: (id) => set({ templateId: id }),
      setActiveStep: (step) => set({ activeStep: step }),
      toggleDarkMode: () => set((state) => ({ isDarkMode: !state.isDarkMode })),
      setApiKey: (key, provider) => set({ apiKey: key, apiProvider: provider }),
      
      // Saved Resumes Management
      saveCurrentResume: () => set((state) => {
        const existingIdx = state.savedResumes.findIndex((r) => r.id === state.resumeData.id);
        const updatedResume: SavedResume = {
          id: state.resumeData.id,
          title: state.resumeData.title,
          lastSaved: new Date().toISOString(),
          data: state.resumeData,
          theme: state.themeSettings,
          templateId: state.templateId,
          atsScore: 85 // Will be calculated by our scorer
        };
        
        let newList = [...state.savedResumes];
        if (existingIdx >= 0) {
          newList[existingIdx] = updatedResume;
        } else {
          newList.unshift(updatedResume);
        }
        
        return { savedResumes: newList };
      }),
      
      loadResume: (id) => set((state) => {
        const found = state.savedResumes.find((r) => r.id === id);
        if (found) {
          return {
            resumeData: found.data,
            themeSettings: found.theme,
            templateId: found.templateId
          };
        }
        return {};
      }),
      
      deleteResume: (id) => set((state) => ({
        savedResumes: state.savedResumes.filter((r) => r.id !== id)
      })),
      
      createNewResume: () => set((state) => {
        const newId = `resume-${Date.now()}`;
        const newResume = createNewResumeData(newId);
        
        // Save the previous one first
        const currentSavedList = [...state.savedResumes];
        const existingIdx = currentSavedList.findIndex((r) => r.id === state.resumeData.id);
        const activeSaved: SavedResume = {
          id: state.resumeData.id,
          title: state.resumeData.title,
          lastSaved: new Date().toISOString(),
          data: state.resumeData,
          theme: state.themeSettings,
          templateId: state.templateId
        };
        
        if (existingIdx >= 0) {
          currentSavedList[existingIdx] = activeSaved;
        } else {
          currentSavedList.unshift(activeSaved);
        }
        
        return {
          resumeData: newResume,
          themeSettings: defaultThemeSettings,
          templateId: 'modern-minimal',
          savedResumes: currentSavedList,
          activeStep: 0
        };
      }),
      
      importResumeJSON: (jsonString) => {
        try {
          const parsed = JSON.parse(jsonString);
          if (parsed && parsed.personalInfo && Array.isArray(parsed.skills)) {
            const importedResume: ResumeData = {
              id: parsed.id || `resume-${Date.now()}`,
              title: parsed.title || 'Imported Resume',
              lastSaved: new Date().toISOString(),
              personalInfo: parsed.personalInfo,
              summary: parsed.summary || '',
              education: parsed.education || [],
              skills: parsed.skills || [],
              experience: parsed.experience || [],
              projects: parsed.projects || [],
              certifications: parsed.certifications || [],
              internships: parsed.internships || [],
              achievements: parsed.achievements || [],
              languages: parsed.languages || [],
              interests: parsed.interests || [],
              references: parsed.references || []
            };
            
            set({
              resumeData: importedResume,
              themeSettings: parsed.themeSettings || defaultThemeSettings,
              templateId: parsed.templateId || 'modern-minimal'
            });
            return true;
          }
          return false;
        } catch (e) {
          console.error('Import failed', e);
          return false;
        }
      }
    }),
    {
      name: 'resume-builder-storage', // key in local storage
      partialize: (state) => ({
        savedResumes: state.savedResumes,
        resumeData: state.resumeData,
        themeSettings: state.themeSettings,
        templateId: state.templateId,
        apiKey: state.apiKey,
        apiProvider: state.apiProvider,
        isDarkMode: state.isDarkMode
      })
    }
  )
);
